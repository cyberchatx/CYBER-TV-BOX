/* CYBER TV ESP32 bridge client */
window.CyberTV = (() => {
  const defaultUrl = "http://192.168.4.1";
  const getBase = () => (localStorage.getItem("cybertv_api") || defaultUrl).replace(/\/+$/, "");

  async function request(path, options = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const response = await fetch(getBase() + path, {
        ...options,
        signal: controller.signal,
        headers: { "Content-Type": "application/json", ...(options.headers || {}) }
      });
      if (!response.ok) throw new Error("HTTP " + response.status);
      return await response.json();
    } finally {
      clearTimeout(timeout);
    }
  }

  async function refresh() {
    try {
      const data = await request("/api/status");
      setConnection(true);
      updateText("boxStatus", data.box?.status);
      updateText("displayStatus", data.display?.status);
      updateText("networkStatus", data.network?.status);
      updateText("simStatus", data.modem?.status);
      updateText("wifiStatus", data.wifi?.status);
      updateText("tvStatus", data.tv?.status);
      updateText("recordingStatus", data.recordings?.status);
      updateText("screenStatus", data.display?.screen);
      return data;
    } catch (error) {
      setConnection(false);
      showMessage("Keine Verbindung: " + error.message);
      throw error;
    }
  }

  async function command(name, extra = {}) {
    try {
      const result = await request("/api/command", {
        method: "POST",
        body: JSON.stringify({ command: name, ...extra })
      });
      showMessage(result.message || ("Befehl gesendet: " + name));
      return result;
    } catch (error) {
      showMessage("Befehl nicht übertragen: " + error.message);
      throw error;
    }
  }

  function setConnection(online) {
    document.querySelectorAll("#connectionDot").forEach(el => el.classList.toggle("online", online));
    document.querySelectorAll("#connectionText").forEach(el => el.textContent = online ? "VERBUNDEN" : "NICHT VERBUNDEN");
  }
  function updateText(id, value) {
    if (value === undefined || value === null) return;
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }
  function showMessage(message) {
    document.querySelectorAll("#message").forEach(el => el.textContent = message);
  }
  return { request, refresh, command, getBase, showMessage };
})();
