document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-command]").forEach(button => {
    button.addEventListener("click", async () => {
      button.disabled = true;
      try { await CyberTV.command(button.dataset.command); }
      catch (_) {}
      finally { button.disabled = false; }
    });
  });

  const url = document.getElementById("apiUrl");
  if (url) {
    url.value = CyberTV.getBase();
    document.getElementById("saveConfig")?.addEventListener("click", () => {
      const value = url.value.trim().replace(/\/+$/, "");
      if (!/^https?:\/\/.+/i.test(value)) {
        CyberTV.showMessage("Bitte eine gültige http:// oder https:// Adresse eingeben.");
        return;
      }
      localStorage.setItem("cybertv_api", value);
      CyberTV.showMessage("ESP32-Adresse gespeichert.");
    });
    document.getElementById("testConnection")?.addEventListener("click", async () => {
      try { await CyberTV.refresh(); CyberTV.showMessage("Verbindung erfolgreich."); }
      catch (_) {}
    });
  }

  document.getElementById("brightnessSend")?.addEventListener("click", async () => {
    const value = Number(document.getElementById("brightness").value);
    try { await CyberTV.command("brightness_set", { value }); } catch (_) {}
  });

  if (document.getElementById("connectionText")) {
    CyberTV.refresh().catch(() => {});
  }
});
