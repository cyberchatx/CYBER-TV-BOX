# CYBER TV ESP32 Bridge API – V1

Die Weboberfläche erwartet eine konfigurierbare Basisadresse des ESP32.

## Status
GET /api/status

Beispielantwort:
{
  "box":{"status":"Online"},
  "display":{"status":"Verbunden","screen":"Eingeschaltet"},
  "network":{"status":"4G verbunden"},
  "modem":{"status":"SIM bereit"},
  "wifi":{"status":"WLAN verbunden"},
  "tv":{"status":"Bereit"},
  "recordings":{"status":"0 Aufnahmen"}
}

## Befehle
POST /api/command
Content-Type: application/json

Beispiel:
{"command":"wifi_scan"}

Helligkeit:
{"command":"brightness_set","value":80}

## CORS
Wenn die Weboberfläche auf einem anderen Host als der ESP32 läuft, muss die Firmware
die passenden CORS-Header liefern. Mindestens:
Access-Control-Allow-Origin: https://DEINE-WEBHOST-DOMAIN
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type

Die Firmware muss OPTIONS-Preflight-Anfragen beantworten.

## Sicherheit
Die API darf nicht ungeschützt aus dem öffentlichen Internet erreichbar sein.
Für Fernzugriff braucht es Authentifizierung und eine abgesicherte Verbindung.
Befehle wie Neustart sollten zusätzlich bestätigt und autorisiert werden.

## Hinweis
Die Oberfläche sendet Befehle, führt aber keine Hardwarefunktion selbst aus.
Die Firmware muss jeden unterstützten Befehl implementieren.
Nicht implementierte Befehle liefern eine verständliche Fehlermeldung.
