# CYBER TV WEBHOST V1

Mehrseitige Web-Verwaltung für CYBER TV BOX und CYBER TV DISPLAY.

- Dashboard
- Box-Verwaltung
- Display-Verwaltung und Remote-Steuerung
- ESP32 API Bridge Client
- Konfigurierbare ESP32-Adresse
- API-Spezifikation in docs/ESP32_API.md

Die Oberfläche ist eine eigenständige Web-App. Hardwarefunktionen benötigen
passende API-Endpunkte in der ESP32-S3-A7670E-Firmware.
